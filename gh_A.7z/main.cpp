#include <iostream>  // NOLINT

/**
 * The main function of a C++ program.
 *
 * @return int The exit status code of the program.
 *
 * @throws None
 */
int main() {
    std::cout << "Hello, world!" << std::endl;
return 0;
}
